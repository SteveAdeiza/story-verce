
import {storyData} from '@/content/stories'

export default function Reader({params}:{params:{storyId:string}}){
const episode = storyData.find((x:any)=>x.id===params.storyId)

if(!episode){
return <div className='container'><h1>Not Found</h1></div>
}

const pages = Array.from({length:7}).map((_,i)=>({
title:`Story Page ${i+1}`,
text:`In this chapter, warriors cross burning kingdoms, dragons fly above the mountains and the royal bloodline discovers hidden powers that may save the empire from darkness.`
}))

return (
<div className='container'>
<div className='cover'>{episode.title}</div>

<div className='card'>
<h1>{episode.title}</h1>
<p>{episode.summary}</p>
</div>

{pages.map((page:any,index:number)=>(
<div className='page' key={index}>
<h2>{page.title}</h2>

<img
src={`/covers/scene-${(index%5)+1}.png`}
style={{width:'100%',borderRadius:'14px',marginBottom:'15px'}}
/>

<p>{page.text}</p>
</div>
))}
</div>
)
}
