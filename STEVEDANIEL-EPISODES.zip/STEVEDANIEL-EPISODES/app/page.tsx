
import Link from 'next/link'
import {storyData} from '@/content/stories'

export default function Home(){
return (
<div>
<section className='hero'>
<h1 style={{fontSize:'60px'}}>The Kingdom is Ours</h1>
<p>Fantasy cinematic story universe.</p>
</section>

<div className='container'>
<div className='grid'>
{storyData.map((ep:any)=>(
<Link href={`/reader/${ep.id}`} key={ep.id}>
<div className='card'>
<div className='cover'>{ep.title}</div>
<h2>{ep.title}</h2>
<p>{ep.summary}</p>
</div>
</Link>
))}
</div>
</div>
</div>
)
}
